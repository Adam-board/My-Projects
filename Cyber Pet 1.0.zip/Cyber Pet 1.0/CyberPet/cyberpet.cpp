#include <iostream>

using namespace std;

int main() {

	int MenuChoice = 0;
	int Hunger = 4;
	int Food = 5;
	int Tiredness = 4;
	int Money = 100;
	int Stress = 4;


	//this area calls upon the functions which are located below the main section.
	int HungerState(int&, int&);
	int SleepState(int&, int&);
	int PlayingGames(int&, int&, int&);
	int Job(int&, int&, int&, int&);
	int Shop(int&, int&, int&, int&);
	void CheckCurrentState(int, int, int, int, int);

	//ensures the program will keep running until either one of these three stats reach zero or the user exits the program
	while (MenuChoice != 7 && Hunger != 0 && Tiredness != 0 && Stress != 0) {

		// this is input validation so the user doesn't input a value that doesn't work
		do {
			cout << endl;
			cout << "Please select what you would like to do with your CyberPetTM:\n";
			cout << "1.Feed\n";
			cout << "2.Sleep\n";
			cout << "3.Check Current State\n";
			cout << "4.Play a Game\n";
			cout << "5.Work(Gives money for food)\n";
			cout << "6.Shop(buying more churros!!!)\n";
			cout << "7.Quit\n";

			cin >> MenuChoice;
			cout << endl;
		} while (MenuChoice < 1 && MenuChoice > 7);
		
		//Makes it appear as though the console iswiped after every use
		cout << string(50, '\n');
		
		//This makes selecting a function more efficient using a switch statement rather than many if statements
		switch (MenuChoice) {

		case 1:
			HungerState(Hunger, Food);
			break;
		case 2:
			SleepState(Tiredness, Hunger);
			break;
		case 3:
			CheckCurrentState(Hunger, Food, Tiredness, Money, Stress);
			break;
		case 4:
			PlayingGames(Tiredness, Stress, Hunger);
			break;
		case 5:
			Job(Money, Stress, Tiredness, Hunger);
			break;
		case 6:
			Shop(Hunger, Tiredness, Money, Food);
			break;
		case 7:
			cout << "Come back to look after me soon!\n";
			break;
		}
	}

	//this if statement is for when you finish your game and either die or just quit and you get a different text ending depending on how you finish the game
	if (Hunger == 0) {

		cout << "Your CyberPetTM has died from starving, Game Over!\n";

	}
	else if (Tiredness == 0) {

		cout << "Your CyberPetTM has died from collapsing and banging their head, Game Over!\n";
	}
	else if (Stress == 0) {

		cout << "Your CyberpetTM has died of overstressing, Game Over!\n";

	}
	else {
		cout << "Thanks for Playing!\n";
	}

}

// HungerState is the function for feeding the CyberpetTM and can only be fed when not full and has food on them 
int HungerState(int& Hunger, int& FoodDecrease) {

	if (Hunger != 4 && FoodDecrease != 0) {

		Hunger = Hunger + 1;
		FoodDecrease = FoodDecrease - 1;
	}
	else {
		cout << "Your pet is full or you have no food to feed the CyberPetTM\n";
	}

	return Hunger, FoodDecrease;
}

//SleepState is the function for sleeping and can only sleep when they are not fully rested

int SleepState(int& Tired, int& Hunger) {

	if (Tired != 4) {

		Tired = Tired + 1;
		Hunger = Hunger - 1;
	}
	else {
		cout << "Your pet is fully rested\n";
	}

	return Hunger, Tired;
}

// PlayingGames is the function to play games to reduce stress so you are able to work again

int PlayingGames(int& Tired, int& StressDecrease, int& Hunger) {

	if (StressDecrease != 4) {

		StressDecrease = StressDecrease + 1;
		Tired = Tired - 1;
		Hunger = Hunger - 1;
	}
	else {
		cout << "You are completely relaxed and don't need to play any games\n";
	}

	return StressDecrease, Tired, Hunger;
}
// Job is the function for working to get currency so you can buy food to feed your CyberPetTM
int Job(int& Cash, int& StressIncrease, int& Tired, int& Hunger) {

	if (StressIncrease != -1) {

		Cash = Cash + 40;

		StressIncrease = StressIncrease - 1;

		Tired = Tired - 1;

		Hunger = Hunger - 1;
		//one job shift gives enough money for two levels of hunger
		cout << "You work very hard at hacking the cyberpet Corp. and earn: 40 moneys\n";

	}
	return Cash, StressIncrease, Tired, Hunger;
}

//Shop is where you buy your food after working
int Shop(int& hunger, int& tiredness, int& money, int& food) {

	if (money >= 20) {

		food = food + 1;
		hunger = hunger - 1;
		tiredness = tiredness - 1;
		money = money - 20;
	}
	else {
		//ensures you can't buy more food when you don't have the money for it
		cout << "You have no money, work to get money for food!\n";
	}
	return hunger, tiredness, money, food;
}


// allows you check all the stats of the pet like hunger, food amount, tiredness, money and stress
void CheckCurrentState(int hunger, int food, int tiredness, int money, int stress) {

	cout << "Hunger: ";
	switch (hunger) {
		//sets of the different stages of hunger for each number
	case 1:
		cout << "Starving\n";
		break;
	case 2:
		cout << "Rather Hungry\n";
		break;
	case 3:
		cout << "Slightly Peckish\n";
		break;
	case 4:
		cout << "Well Fed\n";
		break;
	}
	// Sets out the different stages of tiredness for each number
	cout << "Tiredness: ";
	switch (tiredness) {

	case 1:
		cout << "Falling Asleep\n";
		break;
	case 2:
		cout << "Tired\n";
		break;
	case 3:
		cout << "Awake\n";
		break;
	case 4:
		cout << "Wide Awake\n";
		break;
	}
	// Sets out the different stages of stress for each number
	cout << "Stress: ";
	switch (stress) {

	case 1:
		cout << "Breaking Down\n";
		break;
	case 2:
		cout << "Really Anxious\n";
		break;
	case 3:
		cout << "Anxious\n";
		break;
	case 4:
		cout << "Calm\n";
		break;
	}
	//displays the currency and food amount available
	cout << "Food: " << food << " churros" << endl;
	cout << "Money: " << money << " gold" << endl;
}
