#include <iostream>

using namespace std;

int main() {


	for (int bottles = 99; bottles > 1; bottles--) {

		cout << bottles << " bottles of beer on the wall, " << bottles
			<< " bottles of beer. Take one down, pass it around "
			<< bottles -1 << " bottles of beer on the wall";
		cout << endl;

	}

	cout << "No more bottles of beer on the wall, no more bottles of beer. Go to the store and buy some more, 99 bottles of beer on the wall" << endl;

	return 0;
}