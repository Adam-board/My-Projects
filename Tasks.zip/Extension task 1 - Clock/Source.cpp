#include <iostream>

using namespace std;

int main() {

	int hours, minutes, seconds;

	cout << "Please enter hours in 24 hour format (i.e 05, 17, 00)" << endl;
	cin >> hours;

	while (hours < 0 || hours > 25) {

		cout << "please ensure it is in 24 hour format" << endl;
		cin >> hours;


	}

	int hours_in_seconds = hours * 60 * 60;

	cout << "Please enter minutes (i.e 05, 17, 59)" << endl;
	cin >> minutes;

	cout << "Please enter seconds (i.e 05, 17, 59)" << endl;
	cin >> seconds;

	while (minutes < 0 || minutes > 59) {

		cout << "please ensure it is between 0 and 59 minutes" << endl;
		cin >> minutes;


	}

	int minutes_in_seconds = minutes * 60;

	while (seconds < 0 || seconds > 59) {

		cout << "please ensure it is between 0 and 59 seconds" << endl;
		cin >> seconds;


	}

	int time_elapsed = hours_in_seconds + minutes_in_seconds + seconds;

	cout << time_elapsed << endl;
}