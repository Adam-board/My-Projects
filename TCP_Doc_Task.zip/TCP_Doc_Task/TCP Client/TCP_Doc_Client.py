#Name: TCP_Doc_Client.py
#Desc: This is the serverside for sending documents and telling the user how many characters and words are in the document and tell the client
#Auth: Adam Board
#Date: 2/12/2020



import socket

if __name__ == '__main__':

    #Declares the host and server port and is 
    #the same as the server's host and port
    Server_Host = '127.0.0.1'
    Server_Port = 10101

    #Declares it as TCP and Connect
    Client_Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    Client_Socket.connect((Server_Host, Server_Port))

    #Declares that the file is in the system
    Open_File = open('Not_A_Rickroll.txt', 'r')

    #Puts all of the data inside of the file onto a variable
    File_To_Send = Open_File.read()

    #Sends to the server 
    Client_Socket.sendall(File_To_Send.encode())

    Open_File.close()

    Received_Num_Chars, Server_Address = Client_Socket.recvfrom(4096)
    Received_Num_Words, Server_Address = Client_Socket.recvfrom(4096) 

    Num_Chars = int(Received_Num_Chars.decode())
    Num_Words = int(Received_Num_Words.decode())

    Final_Answer = 'There is {} characters and {} words in this text file'
    print(Final_Answer.format(Num_Chars, Num_Words))

    Client_Socket.close()


