#Name: TCP_Doc_Server.py
#Desc: This is the serverside for sending documents and telling the user how many characters and words are in the document and tell the client
#Auth: Adam Board
#Date: 2/12/2020

import socket

if __name__ == '__main__':

    #Declares the host and the server port
    Server_Host = '127.0.0.1'
    Server_Port = 10101

    #This declares the server as TCP and binds it to the client and listens for a response
    Server_Socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    Server_Socket.bind((Server_Host, Server_Port))
    Server_Socket.listen()

    Incoming_Connection, Client_Address = Server_Socket.accept()

    print('Server is ready and connected!')

    while True:
        Incoming_File = Incoming_Connection.recv(4096)
        if not Incoming_File:
            break
        
        #without the split it counts all of the characters in the file, including whitespace
        #with the split it counts only full words
        Num_of_Chars = str(len(Incoming_File))
        Num_of_words = str(len(Incoming_File.split()))

        #Sends the data required back to the client
        Incoming_Connection.sendall(Num_of_Chars.encode())
        Incoming_Connection.sendall(Num_of_words.encode())