//This program will search through an entire PC's hard disk and hash every single file that it can find
//Adam Board
//This was made and only works in C++20 since filesystem library is a C++17 only library and semaphores are a c++20 library item
//This also makes use of the external library OpenSSl which is required for the hashing to work
// OpenSSL can be obtained from https://slproweb.com/products/Win32OpenSSL.html which has a static binary version instead of having to install all the packages
//There is an exception to files that the filesystem library cannot access due to permissions of the program, even running in administrator does not fix this, therefore i chose to skip any files that cannot be accessed due to privilege errors


//the external library needs to be specified within the visual studio "Project" tab
// Inside of the C/C++ there is a sub-area called general "<filepath>\OpenSSL-Win64\include" needs to be in the include directories section
// Inside of the Linker General section "<filepath>\OpenSSL-Win64\lib" needs to be put within additional library directories area
// Inside of Linker Input section "openssl.lib;libcrypto.lib;" these two libraries need to be included to function properly