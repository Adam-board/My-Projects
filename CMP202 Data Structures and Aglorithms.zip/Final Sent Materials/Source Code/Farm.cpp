#include "farm.h"

#include <thread>
#include <stack>
#include <queue>


//stops threads from all checking if its empty
std::mutex EmptyCheck;



void Farm::add_task(Task* task)
{
	farming.push(task);

}

void Farm::run()
{

	auto FarmTasks = [&] {
		while (!farming.empty()) {

			TaskLocking->lock();
			Task* t = farming.front();
			farming.pop();
			TaskLocking->unlock();

   			t->run();
			
		}

	};

	for (int counter = 0; counter < ConThreads; counter++) {

		ThreadCount.push_back(new std::thread(FarmTasks));
	}

	for (int counter = 0; counter < ConThreads; counter++) {

		ThreadCount[counter]->join();
	}

}

int Farm::GetConThreads()
{
	return ConThreads;
}
