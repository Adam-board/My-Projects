#include "Hasher.h"

void Hasher::GotTheMovesMcHasher()
{



}
