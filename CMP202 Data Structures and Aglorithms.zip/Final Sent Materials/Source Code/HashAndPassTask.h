#pragma once
#pragma warning(disable : 4996)
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <vector>
#include <string>
#include <mutex>
#include <thread>
#include <openssl/md5.h>
#include <condition_variable>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <semaphore>
#include "task.h"

namespace Filesys = std::filesystem;


class HashAndPassTask :
    public Task
{
public:
    
    
    HashAndPassTask(Filesys::path& PathnameExt, std::ofstream* MyFileExt, std::binary_semaphore* SemaphoreExt  ) {
    
        PathName = PathnameExt;
    
        MyFile = MyFileExt;
    
        WritingSem = SemaphoreExt;

    };
    
    
    
    void run();

    
private:
    MD5_CTX md5Context;
    char buf[1024 * 16];
    Filesys::path PathName;
    std::ofstream* MyFile;
    std::binary_semaphore* WritingSem;
};

