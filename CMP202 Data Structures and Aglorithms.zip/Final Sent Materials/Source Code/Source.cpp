//This program will search through an entire PC's hard disk and hash every single file that it can find
//Adam Board
//This was made and only works in C++20 since filesystem library is a C++17 only library and semaphores are a c++20 library item
//This also makes use of the external library OpenSSl which is required for the hashing to work
// OpenSSL can be obtained from https://slproweb.com/products/Win32OpenSSL.html which has a static binary version instead of having to install all the packages
//There is an exception to files that the filesystem library cannot access due to permissions of the program, even running in administrator does not fix this, therefore i chose to skip any files that cannot be accessed due to privilege errors

#include <iostream>
#include <fstream>
#include <filesystem>
#include <vector>
#include <openssl/md5.h>
#include <string>
#include <mutex>
#include <thread>
#include "FileDiggerSingleThread.h"
#include "FileDiggerMultiThread.h"
#include "Farm.h"
#include "FilterTask.h"
#include "HashAndPassTask.h"
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <semaphore>

using namespace std::chrono_literals;
using std::unique_lock;
using std::mutex;
using std::chrono::duration_cast;
using std::chrono::milliseconds;
using the_clock = std::chrono::steady_clock;

namespace Files = std::filesystem;

std::binary_semaphore* WritingSem = new std::binary_semaphore{ 0 };
mutex* WritingVector = new mutex;
mutex* TaskLocking = new mutex;

int main() {
	srand(time(NULL));	
	/*
	//This section deals with single thread version of the program as its the more efficient method in single threading.
	
	std::ofstream myfile;
	std::ofstream myTimings;

	//Allows the user to select the extension to look for
	Searching.UserChoice();

	//since it is less costly on the CPU to keep the file open it is outside of the loop (more taxing on CPU to open and close the file location)
	//Opens the file for the hashes to be inserted
	
	//Opens the file for the timings to be inserted into
	myTimings.open("TimingsSingleThread.csv");
	myTimings << "Timing(ms), Num Of Threads,\n";

	
		FileDiggerSingleThread Searching;
		myfile.open("SingleHashes.csv", std::ofstream::out | std::ofstream::trunc);
		myfile << "FilePath, HashValue(checksum),\n";

		the_clock::time_point startTime = the_clock::now();
		//Searches for all files with the extension .jpg so they can be ready for hashing
		std::vector<Files::path> TransferVector = Searching.Filesearcher();


		//Displays all the paths on extension that is chosen



		//Hashes the files and sends the hash to a csv file alongside the path of the file
		for (auto& i : TransferVector) {


			myfile << i << "," << Searching.Hashingmd5(i) << std::endl;

		}

		the_clock::time_point endTime = the_clock::now();

		auto time_taken_to_Hash_Single_Thread = duration_cast<milliseconds>(endTime - startTime).count();


		myTimings << time_taken_to_Hash_Single_Thread << ", 1" << std::endl;
		myfile.close();
	
		
		myTimings.close();
	
	*/
	
	//Below this comment is the MultiThreaded Version of the program 
	std::ofstream myfile;
	std::ofstream myTimings;
	
	
	//Opens the file for the timings to be inserted into
	myTimings.open("TimingsMultiThread.csv");
	myTimings << "Timing(ms), Num Of Threads,\n";

	
		FileDiggerMultiThread jpgMulti;
		Farm* ThreadPoolFilter = new Farm(TaskLocking);
		Farm* ThreadPool = new Farm(TaskLocking);
		WritingSem->release();
		//Opens the file for the hashes to be inserted
		myfile.open("MultiHashes.csv", std::ofstream::out | std::ofstream::trunc);
		myfile << "FilePath, HashValue(checksum),\n";


		jpgMulti.UserChoice();
		the_clock::time_point startTime = the_clock::now();

		//Searches for all files with the extension .jpg so they can be ready for hashing
		jpgMulti.Searcher();
		std::vector<Files::path> TransferVector;

		std::string Extension = jpgMulti.GetExtension();

		for (auto& i : jpgMulti.GetAllFiles()) {

			ThreadPoolFilter->add_task(new FilterTask(i, &TransferVector, Extension, WritingVector));
		}

		ThreadPoolFilter->run();

		//Hashes the files and sends the hash to a csv file alongside the path of the file
		for (auto& i : TransferVector) {

			ThreadPool->add_task(new HashAndPassTask(i, &myfile, WritingSem));

		}

		ThreadPool->run();

		//Two different farms are used because the data from the first one is required to know how many tasks are gonna be required in the second farm

		the_clock::time_point endTime = the_clock::now();

		auto time_taken_to_Hash_multi_Thread = duration_cast<milliseconds>(endTime - startTime).count();
		
		//sends the timings to a file
		myTimings << time_taken_to_Hash_multi_Thread << "," << ThreadPool->GetConThreads() << std::endl;
		myfile.close();
		
		myTimings.close();
		
		
	return 0;
}