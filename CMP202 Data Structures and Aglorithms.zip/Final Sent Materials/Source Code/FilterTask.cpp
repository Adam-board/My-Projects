#include "FilterTask.h"

void FilterTask::run()
{

    
    
    //This is the filter for the specific extension that is wanted by the user.
    if (std::filesystem::is_regular_file(input) && input.has_extension())
    {
        auto extension = input.extension();
        if (extension == std::string("." + Extension))
        {
        //Pushes the filtered out file to a vector for the next task
            MutexLock->lock();
            Filtered->push_back(input);
            MutexLock->unlock();
        }

    }  
}
