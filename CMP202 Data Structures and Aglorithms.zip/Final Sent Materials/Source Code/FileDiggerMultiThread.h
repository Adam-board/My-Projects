#pragma once
#pragma warning(disable : 4996)
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <vector>
#include <string>
#include <mutex>
#include <thread>
#include <openssl/md5.h>
#include <condition_variable>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include "task.h"


using std::chrono::duration_cast;
using std::chrono::nanoseconds;
using the_clock = std::chrono::steady_clock;
using std::condition_variable;
namespace Filesys = std::filesystem;
using MyThreads = std::thread;


class FileDiggerMultiThread 
{
public:

	FileDiggerMultiThread(){};


	//Required for the hashing to work
	MD5_CTX md5Context;
	char buf[1024 * 16];


	void UserChoice();
	std::string GetExtension();
	void Searcher();
	std::string Hashingmd5(Filesys::path PathName);
	bool run(Filesys::path input);
	std::vector<Filesys::path> GetAllFiles();

private:
	std::vector<Filesys::path> AllFiles;
	std::string Extension = "jpg";
};

