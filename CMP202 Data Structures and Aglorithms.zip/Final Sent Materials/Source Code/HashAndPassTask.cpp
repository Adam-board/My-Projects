#include "HashAndPassTask.h"

void HashAndPassTask::run()
{
    //whole process takes the whole pathname and hashes the file at the end of the path
    std::ifstream file(PathName, std::ifstream::binary);
   
    MD5_Init(&md5Context);
    
    while (file.good()) {
        file.read(buf, sizeof(buf));
        MD5_Update(&md5Context, buf, file.gcount());
    }
    unsigned char result[MD5_DIGEST_LENGTH];
    MD5_Final(result, &md5Context);

    std::stringstream md5string;
    md5string << std::hex << std::uppercase << std::setfill('0');
    for (const auto& byte : result)
        md5string << std::setw(2) << (int)byte;

    //saves the end file into a .csv file
    WritingSem->acquire();
    *MyFile << PathName << "," << md5string.str() << std::endl;
    WritingSem->release();


}
