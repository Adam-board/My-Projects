#pragma once
#include "Task.h"
#pragma warning(disable : 4996)
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <vector>
#include <string>
#include <mutex>
#include <thread>
#include <condition_variable>
#include <cstdlib>
#include <ctime>
#include <chrono>

namespace Filesys = std::filesystem;



class FilterTask :
    public Task
{
public:
    FilterTask(Filesys::path& inputExt, std::vector<Filesys::path>* FilteredExt, std::string& ExtensionExt, std::mutex* MutexExt) {

        input = inputExt;
        Filtered = FilteredExt;
        Extension = ExtensionExt;
        MutexLock = MutexExt;
    }

    void run();

   
private:
    std::mutex* MutexLock;
    std::string Extension;
    Filesys::path input;
    std::vector< Filesys::path>* Filtered;
};

