#include "FileDiggerSingleThread.h"


std::vector<Filesys::path> FileDiggerSingleThread::Filesearcher()
{
    
   
   
    std::string UserChoice = Extension;
    //This will search the entire file path from the starting location within the brackets and skips files it doesn't have perms to access
    Filesys::recursive_directory_iterator DirectoryPosition{ "D:\\",Filesys::directory_options::skip_permission_denied };



    //filters out anything that doesn't have the extension that is being looked for
    std::copy_if(begin(DirectoryPosition), end(DirectoryPosition),
        std::back_inserter(FilesToBeHashed),
        [&UserChoice](const Filesys::path& p) {
            if (Filesys::is_regular_file(p) && p.has_extension())
            {
                auto ext = p.extension();
                return ext == std::string("." + UserChoice);
            }




            

            return false;
        });

    return FilesToBeHashed;
}

void FileDiggerSingleThread::UserChoice()
{
    //This lets the user choose what file extension they are looking for
    std::cout << "Please select the extension to look for (only the letters themselves, don't include the dot otherwise it won't find anything)" << std::endl;
    std::cin >> Extension;


}

void FileDiggerSingleThread::ShowVector()
{
    //shows all the files to be hashed within the vector
    for (auto& i : FilesToBeHashed) {
        std::cout << i << std::endl;
    }
}

std::string FileDiggerSingleThread::Hashingmd5(Filesys::path PathName)
{

    std::ifstream file(PathName, std::ifstream::binary);
MD5_CTX md5Context;
MD5_Init(&md5Context);
char buf[1024 * 16];
while (file.good()) {
    file.read(buf, sizeof(buf));
    MD5_Update(&md5Context, buf, file.gcount());
}
unsigned char result[MD5_DIGEST_LENGTH];
MD5_Final(result, &md5Context);

std::stringstream md5string;
md5string << std::hex << std::uppercase << std::setfill('0');
for (const auto& byte : result)
md5string << std::setw(2) << (int)byte;

return md5string.str();



}
