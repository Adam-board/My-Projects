#pragma once
#pragma warning(disable : 4996)
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <vector>
#include <string>
#include <openssl/md5.h>
#include <cstdlib>
#include <ctime>
#include <chrono>




namespace Filesys = std::filesystem;

class FileDiggerSingleThread
{
public: 

	FileDiggerSingleThread() {};

	//Files required for hashing
	MD5_CTX md5Context;
	
	char buf[1024 * 16];
	void UserChoice();
	std::vector<Filesys::path> Filesearcher();
	void ShowVector();
	std::string Hashingmd5(Filesys::path pathName);

private:
	std::vector<Filesys::path> FilesToBeHashed;
	std::string Extension = "jpg";
};

