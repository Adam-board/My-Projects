#include "FileDiggerMultiThread.h"




void FileDiggerMultiThread::UserChoice()
{
    
    std::cout << "Please select the extension to look for (only the letters themselves, don't include the dot otherwise it won't find anything)" << std::endl;
    std::cin >> Extension;


}

std::string FileDiggerMultiThread::GetExtension()
{
    return Extension;
}

void FileDiggerMultiThread::Searcher()
{
 
    //This searches through the computer's directory and unfortunately cannot be multithreaded
    Filesys::recursive_directory_iterator DirectoryPosition{ "D:\\", Filesys::directory_options::skip_permission_denied };

    //This copies all the data that was gathered from the last function and then inserts it into the AllFiles vector
    std::copy(begin(DirectoryPosition), end(DirectoryPosition), std::back_inserter(AllFiles));
}



std::string FileDiggerMultiThread::Hashingmd5(Filesys::path PathName)
{
    
    std::ifstream file(PathName, std::ifstream::binary);
    MD5_Init(&md5Context);
    while (file.good()) {
        file.read(buf, sizeof(buf));
        MD5_Update(&md5Context, buf, file.gcount());
    }
    unsigned char result[MD5_DIGEST_LENGTH];
    MD5_Final(result, &md5Context);

    std::stringstream md5string;
    md5string << std::hex << std::uppercase << std::setfill('0');
    for (const auto& byte : result)
        md5string << std::setw(2) << (int)byte;

    return md5string.str();


     
}


bool FileDiggerMultiThread::run(Filesys::path input)
{
    //This is the filter for the specific extension that is wanted by the user.
    if (std::filesystem::is_regular_file(input) && input.has_extension())
    {
        auto extension = input.extension();
        if (extension == std::string("." + Extension))
        {

            return true;
        }
    
    }
    return false;
}

std::vector<Filesys::path> FileDiggerMultiThread::GetAllFiles()
{
    return AllFiles;
}

