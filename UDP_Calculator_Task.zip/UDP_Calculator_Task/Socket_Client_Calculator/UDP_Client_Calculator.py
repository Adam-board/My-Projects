#Name: Socket_Client.py
#Desc: My clientside python
#Auth: Adam Board
#Date: 27/11/2020


import socket

def Calculator(): 
    
    #Below i have declared the server's name and the port that it connects to on the serverside, i have also declared that it is on a udp connection and not tcp
    Server_Name = '127.0.0.1'
    Server_Port = 13370
    Client_Socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    #this allows the user to input values that get sent to the server
    User_Number1 = input('Input first number \n')
    User_Number2 = input('Input second number \n')
    User_Operator = input('Input what operator you would like to use(+, -, /, *) \n')
    
    #validates that the user inputs numbers
    if User_Number1.isnumeric() is not True or User_Number2.isnumeric() is not True:
        Print('Please use numbers next time!')
        Client_Socket.close()
    else:
        pass

    #Sends the data of each input to the designated variable that correlates with each one on the server
    Client_Socket.sendto(User_Number1.encode(), (Server_Name, Server_Port))
    Client_Socket.sendto(User_Number2.encode(), (Server_Name, Server_Port))
    Client_Socket.sendto(User_Operator.encode(), (Server_Name, Server_Port))

    #Receives the output from the server and displays it for the user to view
    Modified_Message, Server_Address = Client_Socket.recvfrom(2048)
    
    #The format command when printing allows me to directly format a integer and string together
    Final_Value = 'The final value is: {}'
    print(Final_Value.format(Modified_Message.decode()))
   
    Client_Socket.close()

if __name__ == '__main__':
    Calculator()