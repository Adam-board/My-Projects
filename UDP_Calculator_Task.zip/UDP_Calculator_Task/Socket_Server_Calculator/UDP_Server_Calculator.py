#Name: Socket_Server_Calculator.py
#Desc: My serverside python for using the calculator
#Auth: Adam Board
#Date: 30/11/2020


import socket

if __name__ == '__main__':

    #Matches the port that is written on the client so they can communicate and binds them
    Server_Port = 13370
    Server_Socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    Server_Socket.bind(('127.0.0.1', Server_Port))
    print('Server is ready')

    #this ensures that if there is no response then the server doesn't run forever taking up resources
    Count = 0

    while Count is not 3:

        Count += 1

        #matches the values being sent from the client so it can receive them
        Inc_Num1, Client_Address = Server_Socket.recvfrom(2048)
        Inc_Num2, Client_Address = Server_Socket.recvfrom(2048)
        Inc_Op, Client_Address = Server_Socket.recvfrom(2048)

        #Extra validation to close the server socket so the user cannot input any letters
        #where there is supposed to be numbers
        if str(Inc_Num1).isnumeric() is not True or str(Inc_Num2).isnumeric() is not True:
            Server_Socket.close()
        else:
            pass

        print('Incoming numbers and operator: ', Inc_Num1, Inc_Num2, Inc_Op)

        Number1 = int(Inc_Num1.decode())
        Number2 = int(Inc_Num2.decode())
        Operator = Inc_Op.decode()

        #based on operator chosen it will do one of the following calculations
        if Operator == '+':
            Outgoing_Message = Number1 + Number2
        
        elif Operator == '-':
            Outgoing_Message = Number1 - Number2
        
        elif Operator == '/':
            Outgoing_Message = Number1 / Number2
        
        elif Operator == '*':
            Outgoing_Message = Number1 * Number2
        
        else:
            Outgoing_Message = 'No operator was selected'

        #turns the integer that has been created 
        #into a string that can be encoded and sent back
        Outgoing_Message = str(Outgoing_Message)
    
        print('Outgoing Message: ', Outgoing_Message)
        Server_Socket.sendto(Outgoing_Message.encode(), Client_Address)
    Server_Socket.close()

   

