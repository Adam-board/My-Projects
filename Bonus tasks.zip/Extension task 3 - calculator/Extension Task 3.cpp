#include <iostream>

using namespace std;


int main() {

	float num_one;
	float num_two;
	bool continue_calculator = true;
	char confirm;
	int confirm_ascii;
	char Operator;
	int Operator_ascii;
	int counter;

	cout << "Please input your first number" << endl;
	cin >> num_one;

	while (continue_calculator == true) {

		cout << "What operator would you like to use? (M for multiply, D for divide, A for add, F for factorial and S for subtract. Please ensure you have used capital letters)" << endl;
		cin >> Operator;
		
		Operator_ascii = int(Operator);

		while (Operator_ascii != 77 && Operator_ascii != 68 && Operator_ascii != 65 && Operator_ascii != 83 && Operator_ascii != 70) {

			cout << " Please enter one of the four letters for an operator (M)ultiply, (D)ivide, (A)dd, (F)actorial or (S)ubtract" << endl;
			cin >> Operator;

			Operator_ascii = int(Operator);

		}


		cout << "Please input your second number (if you chose factorial don't worry about this part)" << endl;

		cin >> num_two;



		if (Operator_ascii == 77) {

			num_one = num_one * num_two;

			cout << "Your new value is: " << num_one << endl;

		}
		else if (Operator_ascii == 68) {

			num_one = num_one / num_two;

			cout << "Your new value is: " << num_one << endl;

		}
		else if (Operator_ascii == 65) {

			num_one = num_one + num_two;

			cout << "Your new value is: " << num_one << endl;

		}
		else if (Operator_ascii == 83) {

			num_one = num_one - num_two;

			cout << "Your new value is: " << num_one << endl;

		}
		else if (Operator_ascii == 70) {
			
			counter = num_one;

			while (counter != 1) {

				num_one = num_one * (counter - 1);

				counter = counter - 1;

			}
			
			cout << "Your new value is: " << num_one << endl;

		}

		cout << "Do you want to do another calculation?" << endl;
		cin >> confirm;
		confirm_ascii = int(confirm);

		while (confirm_ascii != 78 && confirm_ascii != 89) {

			cout << "Please put either (Y)es or (N)o" << endl;
			cin >> confirm;
			confirm_ascii = int(confirm);

		}

		if (confirm_ascii == 89) {
			
			continue_calculator = true;

			cout << "we're going for another round of maths!" << endl;

		}
		else if (confirm_ascii == 78) {

			continue_calculator = false;

			cout << "your final value is: " << num_one << endl;

		}

	}
	return 0;
}
