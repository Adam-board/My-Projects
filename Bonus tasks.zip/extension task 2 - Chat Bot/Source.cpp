//chat bot

#include <iostream>

using namespace std;

int main() {

	string Fname;
	char Mood;

	cout << "Hello, my name is chatbot, what's your name?" << endl;
	cin >> Fname;
		cout << Fname << " that is an awesome name!, are you having a good day? (Please put Y or N)" << endl;
	cin >> Mood;

	int Mood_Ascii;

	Mood_Ascii = int(Mood);

	while (Mood_Ascii != 78 && Mood_Ascii != 89 && Mood_Ascii != 110 && Mood_Ascii != 121) {

		cout << "please enter either 'Y', 'y', 'N', 'n'" << endl;
		cin >> Mood;
		Mood_Ascii = int(Mood);
	}
	
	if (Mood_Ascii == 89 || Mood_Ascii == 121) {

		cout << "That�s great to hear" << endl;
	 }
	else if (Mood_Ascii == 78 || Mood_Ascii == 110 ) {

		cout << "I�m sorry to hear that" << endl;

	}


	
}